import 'react-native-gesture-handler';
import * as React from 'react';
import { View, StyleSheet } from 'react-native';
import { Button, IconButton } from 'react-native-paper';
import { NavigationContainer, DrawerActions } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createDrawerNavigator } from '@react-navigation/drawer';

function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Button mode="contained" buttonColor="#2196F3" onPress={() => navigation.navigate('Profile')}>
        Profile
      </Button>
    </View>
  );
}

function ProfileScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Button mode="contained" buttonColor="#2196F3" onPress={() => navigation.navigate('Home')}>
        Go Back Home
      </Button>
    </View>
  );
}

function AboutScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Button mode="contained" buttonColor="#2196F3" onPress={() => navigation.navigate('HomeStack')}>
        Go Back
      </Button>
    </View>
  );
}

const menuButton = (navigation) => ({
  headerLeft: () => (
    <IconButton
      icon="menu"
      onPress={() => navigation.dispatch(DrawerActions.openDrawer())}
    />
  ),
});

const HomeStackNav = createStackNavigator();
function HomeStack() {
  return (
    <HomeStackNav.Navigator>
      <HomeStackNav.Screen
        name="Home"
        component={HomeScreen}
        options={({ navigation }) => menuButton(navigation)}
      />
      <HomeStackNav.Screen name="Profile" component={ProfileScreen} />
    </HomeStackNav.Navigator>
  );
}

const AboutStackNav = createStackNavigator();
function AboutStack() {
  return (
    <AboutStackNav.Navigator>
      <AboutStackNav.Screen
        name="About"
        component={AboutScreen}
        options={({ navigation }) => menuButton(navigation)}
      />
    </AboutStackNav.Navigator>
  );
}

const Drawer = createDrawerNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Drawer.Navigator
        initialRouteName="HomeStack"
        screenOptions={{ headerShown: false }}
      >
        <Drawer.Screen
          name="HomeStack"
          component={HomeStack}
          options={{ drawerLabel: 'Home' }}
        />
        <Drawer.Screen
          name="AboutStack"
          component={AboutStack}
          options={{ drawerLabel: 'About' }}
        />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
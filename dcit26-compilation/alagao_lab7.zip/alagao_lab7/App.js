import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  Image,
  Button,
  TouchableOpacity,
  ActivityIndicator,
  ScrollView,
  StyleSheet,
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

const Stack = createNativeStackNavigator();
const API_URL = 'https://randomuser.me/api';

function HomeScreen({ navigation }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchUser = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch(API_URL);
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const json = await response.json();
      setUser(json.results[0]);
    } catch (e) {
      setError('Could not load a user. Check your connection and try again.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchUser();
  }, [fetchUser]);

  if (loading && !user) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  return (
    <View style={styles.center}>
      {error && <Text style={styles.error}>{error}</Text>}

      {user && (
        <>

          <TouchableOpacity
            onPress={() => navigation.navigate('Profile', { user })}
            disabled={loading}
          >
            <Image source={{ uri: user.picture.large }} style={styles.homeImage} />
          </TouchableOpacity>
          <Text style={styles.homeName}>
            {user.name.first} {user.name.last}
          </Text>
        </>
      )}

      <View style={styles.buttonWrap}>
        <Button
          title={loading ? 'LOADING...' : 'RANDOM USER'}
          onPress={fetchUser}
          disabled={loading}
        />
      </View>
    </View>
  );
}

function Section({ title, children }) {
  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      {children}
    </View>
  );
}

function Row({ label, value }) {
  return (
    <Text style={styles.row}>
      <Text style={styles.rowLabel}>{label}: </Text>
      {value}
    </Text>
  );
}

function ProfileScreen({ route }) {
  const { user } = route.params;
  const { name, location, dob, registered } = user;
  const street = `${location.street.number} ${location.street.name}`;

  return (
    <ScrollView contentContainerStyle={styles.profileContainer}>
      <Image source={{ uri: user.picture.large }} style={styles.profileImage} />
      <Text style={styles.profileName}>
        {name.title} {name.first} {name.last}
      </Text>

      <Section title="About">
        <Row label="Age" value={dob.age} />
        <Row label="Birthday" value={dob.date} />
        <Row label="Gender" value={user.gender} />
        <Row
          label="Address"
          value={`${street}, ${location.city}, ${location.state}, ${location.country} ${location.postcode}`}
        />
        <Row label="Nationality" value={user.nat} />
      </Section>

      <Section title="Contact">
        <Row label="Email" value={user.email} />
        <Row label="Phone" value={user.phone} />
        <Row label="Cell" value={user.cell} />
      </Section>

      <Section title="Account">
        <Row label="Username" value={user.login.username} />
        <Row label="UUID" value={user.login.uuid} />
      </Section>

      <Section title="Other">
        <Row label="Date registered" value={registered.date} />
        <Row label="Years registered" value={registered.age} />
        <Row label="ID" value={user.id.value ? `${user.id.name} ${user.id.value}` : 'N/A'} />
      </Section>
    </ScrollView>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Profile" component={ProfileScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  center: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#f0f0f0',
    padding: 16,
  },
  error: { color: '#b00020', marginBottom: 12, textAlign: 'center' },
  homeImage: { width: 200, height: 200, backgroundColor: '#ddd' },
  homeName: { fontSize: 18, fontWeight: 'bold', marginTop: 12 },
  buttonWrap: { marginTop: 16 },

  profileContainer: {
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#f0f0f0',
    flexGrow: 1,
  },
  profileImage: { width: 160, height: 160, backgroundColor: '#ddd' },
  profileName: { fontSize: 20, fontWeight: 'bold', marginTop: 12, marginBottom: 20 },

  section: { alignSelf: 'stretch', marginBottom: 20 },
  sectionTitle: {
    fontSize: 15,
    color: '#666',
    borderBottomWidth: 1,
    borderBottomColor: '#d0d0d0',
    paddingBottom: 4,
    marginBottom: 8,
  },
  row: { fontSize: 14, color: '#222', marginBottom: 4 },
  rowLabel: { fontWeight: '600' },
});
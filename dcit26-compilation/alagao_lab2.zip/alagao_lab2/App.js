import { StyleSheet, Text, View } from 'react-native';



// or any files within the Snack
import AssetExample from './components/AssetExample';

export default function App() {
  return (
    <View style={styles.container}>

<Text style={styles.title}>   
      Student Profile 
     </Text>
     
      <Text style={styles.paragraph}>   
      Name: 
     </Text>
     <Text>Danna Ellize Alagao</Text>
     <Text style={styles.paragraph}>  
     Age:
    </Text>
     <Text>20</Text>
     <Text style={styles.paragraph}>  
     Course/Year/Section:
     </Text>
      <Text>BS Computer Science, 3rd Year, Section 5</Text>
     <Text style={styles.paragraph}>  
     About me:
     </Text>
      <Text>I love creating, from art to softwares, games, or applications</Text>
     <Text style={styles.paragraph}>  
     Achievements:
     </Text>
      <Text>- DOST Scholar (2024 - 2028)</Text>
      <Text>- CvSU Main Student (2024 - 2028)</Text>
      <Text>- Summa/Magna cum laude (2028)</Text>
     <Text style={styles.paragraph}>  
     Skills:
     </Text>
     <Text>-Blender</Text>
     <Text>-Python</Text>
     <Text>-Snack Expo</Text>
     <Text>-Java</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-start',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  title: {
    justifyContent: 'center',
    textAlign: 'center',
    fontSize: 20,
    fontWeight: 'bold',
    margin: 20,
  },
  paragraph: {
    marginTop: 24,
    fontSize: 15,
    fontWeight: 'bold',
    textAlign: 'flex-start',
  },
});

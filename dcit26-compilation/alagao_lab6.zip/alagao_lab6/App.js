import React from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  Platform,
  StatusBar,
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { SafeAreaProvider } from 'react-native-safe-area-context';

const products = [
  {
    key: '1',
    title: 'Amethyst',
    description: 'A purple variety of quartz, popular in jewelry and decoration.',
    rating: '5/5',
  },
  {
    key: '2',
    title: 'Rose Quartz',
    description: 'A soft pink quartz with a milky, translucent look.',
    rating: '4.5/5',
  },
  {
    key: '3',
    title: 'Clear Quartz',
    description: 'A colorless, transparent quartz and one of the most common crystals.',
    rating: '4/5',
  },
  {
    key: '4',
    title: 'Citrine',
    description: 'A yellow to golden-orange quartz with a warm, sunny color.',
    rating: '4.5/5',
  },
  {
    key: '5',
    title: 'Selenite',
    description: 'A soft, white, translucent crystal, often carved into wands and lamps.',
    rating: '4/5',
  },
];

function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <FlatList
        data={products}
        keyExtractor={(item) => item.key}
        contentContainerStyle={styles.list}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.item}
            activeOpacity={0.7}
            onPress={() => navigation.navigate('Product', { product: item })}
          >
            <Text style={styles.itemTitle}>{item.title}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

function ProductScreen({ route }) {
  const { product } = route.params;

  return (
    <View style={styles.container}>
      <View style={styles.details}>
        <Text style={styles.title}>{product.title}</Text>
        <Text style={styles.text}>{product.rating}</Text>
        <Text style={styles.text}>{product.description}</Text>
        <Text style={styles.text}>Key: {product.key}</Text>
      </View>
    </View>
  );
}

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <SafeAreaProvider>
      <StatusBar barStyle="dark-content" />
      <NavigationContainer>
        <Stack.Navigator initialRouteName="Home">
          <Stack.Screen name="Home" component={HomeScreen} />
          <Stack.Screen
            name="Product"
            component={ProductScreen}
            options={{ headerBackTitle: 'Back' }}
          />
        </Stack.Navigator>
      </NavigationContainer>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f2f2f2' },
  list: { padding: 15 },
  item: {
    borderWidth: 1,
    borderColor: '#888',
    borderRadius: 4,
    paddingVertical: 12,
    paddingHorizontal: 10,
    marginBottom: 10,
    backgroundColor: '#f7f7f7',
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.15,
        shadowRadius: 2,
      },
      android: {
        elevation: 2,
      },
    }),
  },
  itemTitle: { fontSize: 16 },
  details: { padding: 15 },
  title: { fontSize: 18, fontWeight: 'bold', marginBottom: 6 },
  text: { fontSize: 14, marginBottom: 4 },
});
import React, { useState } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  Button,
  FlatList,
} from 'react-native';

export default function App() {
  const [enteredText, setEnteredText] = useState('');
  const [items, setItems] = useState([]);
  const addItemHandler = () => {
    if (enteredText.trim().length === 0) {
      return;
    }
    setItems((currentItems) => [
      ...currentItems,
      { id: Date.now().toString(), text: enteredText.trim() },
    ]);
    setEnteredText('');
  };
  return (
    <View style={styles.appContainer}>
   
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.textInput}
          placeholder="Enter Item"
          placeholderTextColor="#aaa"
          value={enteredText}
          onChangeText={setEnteredText}
        />
        <Button title="ADD" color="#2196F3" onPress={addItemHandler} />
      </View>


      <View style={styles.listContainer}>
        <FlatList
          data={items}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <View style={styles.listItem}>
              <Text style={styles.listItemText}>{item.text}</Text>
            </View>
          )}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  appContainer: {
    flex: 1,
    paddingTop: 60,
    paddingHorizontal: 40,
    backgroundColor: '#fff',
  },
  inputContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  textInput: {
    flex: 1,
    height: 44,
    borderWidth: 1,
    borderColor: '#ccc',
    backgroundColor: '#fff',
    paddingHorizontal: 10,
    marginRight: 8,
  },
  listContainer: {
    flex: 1,
  },
  listItem: {
    backgroundColor: '#888',
    borderWidth: 1,
    borderColor: '#777',
    paddingVertical: 10,
    paddingHorizontal: 8,
    marginBottom: 8,
  },
  listItemText: {
    color: '#222',
    fontSize: 12,
  },
});